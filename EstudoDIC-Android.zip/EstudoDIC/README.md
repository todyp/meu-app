# Estudo DIC (app Android)

App Android com **as mesmas funcionalidades do site "Estudo DIC · Legislação"**: todas as seções
(Legislação, Emenda do Corpo Executivo, Modus Operandi, Regulamento Disciplinar, Regulamento Administrativo,
Regimento dos VIPS Interno, Regimento dos Distintivos, Regulamento dos Uniformes, Regimento dos Portadores,
Instruções de Comandos e Regimento do TJP), busca em todas as seções ao mesmo tempo, filtros por capítulo/título
e tema claro/escuro.

O app é um WebView que carrega o site **de dentro do próprio app** (`app/src/main/assets/index.html`).
Por isso funciona **100% offline** e não pede nenhuma permissão (nem internet).

- Botão "voltar": se houver texto na busca, limpa a pesquisa; senão, fecha o app.
- Mínimo: Android 8.0 (API 26).

## Como gerar o APK (Android Studio)

1. Instale o Android Studio (https://developer.android.com/studio).
2. `File > Open` e escolha esta pasta (`EstudoDIC`). Espere o "Gradle Sync" terminar
   (o Android Studio baixa o que precisar; a primeira vez demora).
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. Quando terminar, clique em "locate": o arquivo fica em `app/build/outputs/apk/debug/app-debug.apk`.
5. Passe o arquivo para o celular e instale (talvez precise permitir "instalar apps de fontes desconhecidas").

Para rodar direto no celular: ative a "Depuração USB", conecte o cabo e clique em ▶ Run.

## Sem instalar nada (GitHub Actions) - opcional

Suba esta pasta para um repositório no GitHub. Em `Actions > Build APK > Run workflow`, o APK de debug é gerado
na nuvem e fica disponível para baixar em "Artifacts".

## Como atualizar o conteúdo

Substitua `app/src/main/assets/index.html` pelo arquivo novo do site e gere o APK de novo
(aumente `versionCode` em `app/build.gradle.kts` se quiser instalar por cima de uma versão anterior).
